function [all_mats,O1,O2] = morphospace2D(adj,pos,opt,M,gens,fun1str,fun2str)

% This function explores the 3D morphospace of a network.

% INPUTS
% adj:      NxN adjacency matrix for your network of interest
% pos:      Nx2 or Nx3 matrix where rows correspond to coordinates of nodes.
% opt:      optimization parameter, a 2-bit binary vector (e.g. [1,1,0]). This tells
% you if it will maximize or minimize something. 0 means maximize, 1 means
% minimize. So if we are trying to maximize variable P, minimize Q, and
% maximize R, we would input [0,1,0].
% M:        Number of matrices to put in the population for the evolutionary algorithm. 
% On the order of 100 is usually best.
% gens:     number of generations for the evolutionary algorithm.
% fun1str,
% fun2str:  Strings naming the function to take a network measurement. Make
% sure these functions have only one output. If they have multiple inputs, add the
% inputs to the netparams structure further down in the code.

%OUTPUTS
% all_mats:         A 2xM cell array containing adjacency matrices for the last two
% generations of matrices.
% O1, O2:       Metrics used to define the network morphospace. The
% size is gensxM, so each column represents how a particular network in the
% population over time.

%EXAMPLE
% To explore all octants of the morphospace, use a loop similar to the
% following:

% figure(); hold on
% for i=0:3 %Explore 4 quadrants
%     opt = decimalToBinaryVector(i,2); 
%     [all_mats,Q,L] = morphospace2D(adj,pos,opt,M,gens,'modularity','pathlength');
%       % The code below draws a nice colorful plot.
%     color = decimalToBinaryVector(i,3);
%     for j=1:M
%         plot(Q(:,j),L(:,j),'Color',[color 0.01]);
%         h(i+1) = plot(Q(end,j),L(end,j),'.','MarkerSize',15,'Color',color);
%     end
% end

k = sum(adj(:));
N = length(adj);
distmat = squareform(pdist(pos));

all_mats = cell(2,M);  %Initialize all matrices as minimally rewired
[all_mats{1,:}] = deal(adj);

O1 = zeros(gens,M);
O2 = zeros(gens,M);
fun1 = str2func(fun1str);
fun2 = str2func(fun2str);

% To make a single input argument, use a structure object with the
% parameters you need inside it. In this case, the adjacency matrix and the
% distance matrix.
netparams.adj = adj;
netparams.distmat = distmat;

%Initialize measurements
O1(1,:) = fun1(netparams)*ones(1,M);
O2(1,:) = fun2(netparams)*ones(1,M);

for j=2:gens
    for i=1:M
        all_mats{2,i}=all_mats{1,i}; %Reassign the matrix to the next row of all_mats
        % Edge-swapping section:
        [rows,cols] = find(all_mats{2,i}); % Find edges
        idx1 = randi(k); %Selected edge to switch
        all_mats{2,i}(rows(idx1),cols(idx1)) = 0; %Switch edge value to 0
        [rowcolnew] = randi(N,1,2); %Draw new row and column indices
        while all_mats{2,i}(rowcolnew(1),rowcolnew(2))==1 || rowcolnew(1)==rowcolnew(2) %Draw again if there is already a 1 there or if we are on the diagonal
            [rowcolnew] = randi(N,1,2);
        end
        all_mats{2,i}(rowcolnew(1),rowcolnew(2))=1; % Switch edge value to 1.

        % Enter current adjacency matrix into the parameter structure
        netparams.adj = all_mats{2,i};
        
        %Compute metrics
        O1(j,i) = fun1(netparams);
        O2(j,i) = fun2(netparams);
        
    end
    %Use pareto optimality to determine the pareto front
    
    % Opt determines if the algorithm maximizes (0) or minimizes(1) a
    % parameter.
    front = paretofront([(-1)^opt(1)*O1(j,:)',...
                         (-1)^opt(2)*O2(j,:)']);
    O1(j,~front) = nan;
    O2(j,~front) = nan;
    
%After updating each matrix in the population, replace ones that have nans
%in their measurements. 
    nans = find(isnan(O1(j,:)));
    nonnans = find(~isnan(O1(j,:))); %Find non-nan indices of metrics
    if length(nans)<M %If there are non-nan elements...
        for i=1:length(nans)
            idx = datasample(nonnans,1); %Select a non-nan index
            O1(j,nans(i)) = O1(j,idx);
            O2(j,nans(i)) = O2(j,idx);
            all_mats{2,nans(i)} = all_mats{2,idx}; %Replace the bad matrix with a good one
        end
    else %But if all we have is nans, then we can't do an easy replacement. Go back a generation
        for i=1:M
            O1(j,i) = O1(j-1,i);
            O2(j,i) = O2(j-1,i);
            [all_mats{2,:}] = all_mats{1,:};
        end
        
    end
    [all_mats{1,:}] = all_mats{2,:}; %The new generation becomes the old
end

end